package com.example.thesisall;

public class IndividualStatsController {
}

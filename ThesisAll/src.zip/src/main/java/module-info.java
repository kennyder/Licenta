module com.example.thesisall {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.thesisall to javafx.fxml;
    exports com.example.thesisall;
}